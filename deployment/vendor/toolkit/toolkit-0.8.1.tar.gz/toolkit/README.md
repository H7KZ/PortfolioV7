# VPS toolkit

This is the v1 Ubuntu 26.04 host toolkit. Infrastructure's `scripts/bootstrap-host.sh` installs the
pinned release on a new host, and deploys, rollbacks, backups and boot recovery run under its locks.
It does not replace the `scripts/` chores, the proxy stack, or each repository's boot reconcile unit.

The current commands are `version`, `validate`, `plan`, `firewall plan`, `apply`, `status`, `operation`, `verify-release`, `with-lock`, `install`, `activate`, `release`, `reconcile`, and `backup`.
`validate` parses a host configuration without applying it. `plan` reports the parsed values, host
and platform limits, and read-only swap and Docker logging actions. `firewall plan` inventories the active Docker
firewall backend, competing firewall managers, iptables-nft tools and both Docker user chains; it
does not change rules. It blocks native nftables and Cloudflare mode until their separate strategies
are implemented. The file helper writes through a validated
same-directory temporary and atomic rename. `with-lock` takes a repository-wide lock; add `--host-window` for host mutations. Host-only
commands take only the host lock. Release operations take the repository lock throughout and the
host lock only around Compose changes and health. `install` validates release inputs before changing the installation
tree and stages a checksummed release without activating it; `activate` changes the installed release
symlink only. `operation start`/`finish` publish atomic root-only operation records; `with-lock --action`
records lock-wrapped work automatically. `apply --config <path> --module swap` provisions only the
explicitly selected swap module: it preserves active swap, refuses implicit resize, supports ext4/xfs,
requires requested size plus 1 GiB free, and resumes a valid inactive `/swapfile`. It does not change
sysctl, zswap, or boot settings. `apply --config <path> --module docker-logs` merges bounded
`json-file` defaults (10 MB per file, three files) into Docker's `daemon.json`, preserving unrelated
valid settings and refusing conflicting log settings. It validates the staged file with `dockerd`
before atomic replacement and never restarts Docker; a restart and container recreation are needed
for existing containers to adopt new defaults. Other provisioning modules remain unimplemented.

`backup` (0.7.0) is a generic, app-agnostic backup pipe. `backup run <repo> <4h|daily>` (or the systemd
instance form `<repo>-<cadence>`) loads `/etc/toolkit/backup/<repo>.env` and the repository's component
list, takes only that repository's lock (waiting up to 30 minutes, never `host.lock`), runs each producer
through `zstd` and `age` into a temp file, releases the lock, then uploads each fully successful file with
`rclone copyto` to `daily/` (and `weekly/` on the Sunday daily run). `backup list`, `fetch` and `check` read
the bucket for restore and freshness checks. Repositories supply only the component list; see
`deployment/backups/` in this repo and the [backup plan](../docs/plans/2026-10-backup-redesign.md).

## Local use

```sh
toolkit/bin/toolkit version
toolkit/bin/toolkit validate --config toolkit/config/host.conf.example
toolkit/bin/toolkit plan --config toolkit/config/host.conf.example
toolkit/bin/toolkit firewall plan --config toolkit/config/host.conf.example
toolkit/bin/toolkit apply --config toolkit/config/host.conf.example --module swap
```

Configuration uses literal `KEY=value` lines. It is not sourced or expanded by a shell. See
[`config/host.conf.example`](config/host.conf.example) and the frozen
[`contracts/handoff-v1.md`](contracts/handoff-v1.md).

Package a committed toolkit release with:

```sh
toolkit/packaging/build-release.sh <output-directory>
```

The adjacent SHA-256 file detects corruption; it does not authenticate who published the archive.
Release provenance must come from a reviewed source and authenticated distribution channel.
From a consuming repository checkout, install the exact pinned bundle inactive, then activate it
explicitly:

```sh
sudo bash deployment/install-toolkit.sh
sudo /opt/toolkit/releases/<pinned-version>/bin/toolkit activate <pinned-version>
```

After activation, `/usr/local/bin/toolkit` points to the active release.

## Compose release snapshots (0.8.1)

See [deployment-release-v1](contracts/deployment-release-v1.md) for the manifest and operator commands.
`release stage` checks an archive and renders a complete Compose snapshot. `release deploy` stages
and applies it; `release activate|rollback` applies an existing snapshot, including its saved config
and digests. `reconcile` uses the current snapshot with no pull, build or recreation. Secrets and
resolved Compose JSON live in private `.runtime/<release-id>/` directories outside source releases.
No deploy deletes old releases, images, data or orphans. Capacity and live recovery drills remain
owner work; snapshot tests use Docker stubs and do not establish production readiness.
